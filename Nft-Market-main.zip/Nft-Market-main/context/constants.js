import market from './NFTMarketplace.json';

export const MarketAddress = "0x88634c8743d9c13b72c407c355Dc4E08f2Ba1025"; //Contract Address for PokemonMarket.sol

export const MarketABI = market.abi;
